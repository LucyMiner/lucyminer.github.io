If you can't do a payout contact me for a manually payout: lucyminerservice@gmail.com

=====================================================================================

UPDATE 1.04:

- More stable Miner

=====================================================================================

UPDATE 1.02:

- Grammer fixes
- Bug can't startup fixed
- Smoother payout

=====================================================================================